Package.json sayfasına
"api": "npx json-server --watch ./src/data/data.json" satırı eklenmiştir. 
Bu sebeple projeyi hatasız çalıştırabilmek için terminal üzerinde;
    npm run api (apinin aktifleştirilmesi)
    npm run dev (projenin çalıştırılmasını) 
sağlamaktadır.